package pkg;

import processing.core.PApplet;

public class GOLProcessing extends PApplet {
	public static void main(String[] args) {
		PApplet.main("pkg.GOLProcessing");
	}
	
	Grid grid;
	int rectSize;
	int frame;
	boolean isPaused;
	
	public GOLProcessing()
	{
		int n = 300;
		rectSize = 3;
		
		
		
		frame = 0;
		isPaused = false;
		
		grid = new Grid(n, 0.2);
	}
	
	
	public void settings() {
		size(grid.size()*rectSize, grid.size()*rectSize);
	}
	
	
	public void keyPressed() 
	{
		if(key == ' ')
			isPaused = !isPaused;
	}

	
	
	public void draw(){
		fill(255, 255, 255);
		stroke(255, 255, 255);
		rect(0, 0, grid.size()*rectSize, grid.size()*rectSize);
		
		fill(0, 255, 0);
		stroke(0, 255, 0);
		
		for(int i = 0; i < grid.size(); ++i)
		{
			for(int j = 0; j < grid.size(); ++j)
			{
				if(grid.isAlive(i, j)) {
					rect(i*rectSize, j*rectSize, rectSize, rectSize);
				}
			}
		}
		
		if (mousePressed) {
			int i = mouseX/rectSize;
			int j = mouseY/rectSize;
			if(mouseButton == LEFT)
				grid.setAlive(i, j);
			else if(mouseButton == RIGHT)
				grid.setDead(i, j);
			
		}
		
		
		if(!isPaused && frame >= 10) {
			grid.update();
			frame = 0;
		}
		
		
		++frame;
		
	}
}