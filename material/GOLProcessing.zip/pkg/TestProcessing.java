package pkg;
import processing.core.PApplet;

public class TestProcessing extends PApplet {
	public static void main(String[] args) {
		PApplet.main("pkg.TestProcessing");
	}
	
	
	public void settings() {
		size(500, 500);
	}
	
	
	public void draw(){
		line(0, 0, 500, 500);  
		ellipse(random(0,500),random(0,500),10,10);
		System.out.println("called");
	}
}