package pkg;

public class Grid {
	public static void main(String[] args) {
		int n = 100;
		Grid g = new Grid(n, 0.2);
		
		while(true)
		{
			g.print();
			g.update();

			try {
				Thread.sleep(200);
			}
			catch(InterruptedException e){}

			System.out.print("\033[H\033[2J");
			System.out.flush();
		}
	}
	
	
	final static String ALIVE = "\u2B1B";
	// final static String ALIVE = "x";
	final static String DEAD = "  ";
	
	
	private boolean[][] alive;
	private int n;
	
	public Grid(int size)
	{
		n = size;
		alive = new boolean[size][size];
	}
	
	public Grid(int size, double alivePerc)
	{
		this(size);
		
		for(int i = 0; i < n; ++i)
		{
			for(int j = 0; j < n; ++j)
			{
				alive[i][j] = Math.random() < alivePerc;
			}
		}
	}
	
	public void print()
	{
		for(int i = 0; i < n; ++i)
		{
			for(int j = 0; j < n; ++j)
			{
				if(alive[i][j])
					System.out.print(ALIVE);
				else
					System.out.print(DEAD);
			}
			System.out.println();
		}
	}

	public boolean isAlive(int i, int j)
	{
		//problem i,j < 0 || i,j >= n
		int indexi = (i + n) % n;
		int indexj = (j + n) % n;
		return alive[indexi][indexj];
	}

	private int countAliveNeigh(int i, int j)
	{
		int nAlive = 0;
		for(int x = -1; x <= 1; ++x)
		{
			for(int y = -1; y <= 1; ++y)
			{
				if(x == 0 && y == 0)
					continue;

				if(isAlive(i+x, j+y))
					++nAlive;
			}
		}

		return nAlive;
	}

	public void update()
	{
		boolean[][] newGrid	= new boolean[n][n];

		for(int i = 0; i < n; ++i)
		{
			for(int j = 0; j < n; ++j)
			{
				int nAlive = countAliveNeigh(i, j);

				if(isAlive(i, j))
				{
					if(nAlive < 2)
						newGrid[i][j] = false;
					else if(nAlive == 2 || nAlive == 3)
						newGrid[i][j] = true;
					else //if(nAlive > 3)
					newGrid[i][j] = false;
				}
				else
				{
					if(nAlive == 3)
						newGrid[i][j] = true;
					else
						newGrid[i][j] = false;
				}
			}
		}

		for(int i = 0; i < n; ++i)
		{
			for(int j = 0; j < n; ++j)
			{
				alive[i][j] = newGrid[i][j];
			}
		}
	}

	public int size() {
		return n;
	}

	public void setAlive(int i, int j) {
		alive[i][j]=true;
	}

	public void setDead(int i, int j) {
		alive[i][j]=false;
	}

}
